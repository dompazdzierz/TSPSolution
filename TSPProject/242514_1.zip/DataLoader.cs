﻿using System.Collections.Generic;
using System.IO;

namespace TSPProject
{
    public static class DataLoader
    {
        public static List<Coord> LoadCoordsFromFile(string filePath)
        {
            List<Coord> coords = new List<Coord>();

            if (!File.Exists(filePath))
                throw new FileNotFoundException("Cannot find file of path: " + filePath);
            
            using (StreamReader sr = File.OpenText(filePath))
            {
                string line = "";
                bool isCoordSectionPresent = false;

                while ((line = sr.ReadLine()) != null) 
                { 
                    if (line.StartsWith("NODE_COORD_SECTION"))
                    {
                        isCoordSectionPresent = true;
                        break;
                    }
                }
                
                if (!isCoordSectionPresent)
                    return null;
                    
                while ((line = sr.ReadLine()) != null && !line.StartsWith("EOF"))
                {
                    coords.Add(Coord.ConvertStringToCoord(line, ' '));
                }
            }

            return coords; 
        }
    }
}
