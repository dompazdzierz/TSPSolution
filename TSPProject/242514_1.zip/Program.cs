﻿

namespace TSPProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu.Init();
        }
    }
}
