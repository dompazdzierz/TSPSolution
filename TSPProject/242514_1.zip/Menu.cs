﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TSPProject.Extensions;

namespace TSPProject
{
    class Menu
    {
        public static List<Coord> coords = LoadCoords();

        public static void Init()
        {

            Console.WriteLine("Miasta");
            coords.Write();

            List<Individual> individuals = new List<Individual>();
            
            for (int i = 0; i < 10; i++)
                individuals.Add(GenerateIndividual(coords.Count));

            Console.WriteLine();
            Console.WriteLine("Osobniki");
            foreach (Individual individual in individuals)
            {
                Console.WriteLine("Osobnik: ");
                Console.WriteLine(individual + ": " + CalcFitting(individual));
            }

            for (int i = 0; i < coords.Count; i++)
                Console.WriteLine(GreedyAlgorithm(i));

            var ind = new Individual(Enumerable.Range(0, coords.Count - 1).ToList());
            Console.WriteLine(CalcFitting(ind));

        }

        public static List<Coord> LoadCoords()
        {
            string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(currentDirectory, "DataFiles", "berlin11_modified.tsp");
            return DataLoader.LoadCoordsFromFile(filePath);
        }

        public static Individual GenerateIndividual(int genesNumber)
        {
            var genotype = Shuffle(Enumerable.Range(0, genesNumber - 1).ToList());
            return new Individual(genotype);
        }

        public static double CalcFitting(Individual individual)
        {
            double distance = 0;

            for(int i = 0; i < coords.Count - 2; i++)
            {
                var oneIndex = individual.Genotype[i];
                var otherIndex = individual.Genotype[i + 1];

                distance += coords[oneIndex].CalcDistance(coords[otherIndex]);
            }

            return distance;
        }

        public static double GreedyAlgorithm(int startCity)
        {
            double distance = 0;

            var notVisited = Enumerable.Range(0, coords.Count - 1).ToList();
            var visited = new List<int>();
            visited.Add(startCity);
            notVisited.Remove(startCity);

            for(int i = 0; i < coords.Count - 2; i++)
            {
                double bestValue = coords[startCity].CalcDistance(coords[notVisited[0]]);
                int bestIndex = notVisited[0];
                
                for(int j = 1; j < notVisited.Count; j++)
                {
                    var value = coords[startCity].CalcDistance(coords[notVisited[j]]);
                    if(value < bestValue)
                    {
                        bestValue = value;
                        bestIndex = notVisited[j];
                    }
                }

                distance += bestValue;
                visited.Add(bestIndex);
                notVisited.Remove(bestIndex);
                startCity = bestIndex;
            }

            return distance;
        }

        public static List<T> Shuffle<T>(List<T> list)
        {
            var rng = new Random();

            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }

            return list;
        }
    }
}
