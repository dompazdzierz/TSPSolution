﻿
using System;
using TSPProject.Resolvers;

namespace TSPProject
{
    public abstract class ResolverBase
    {
        protected double[,] AdjacencyMatrix { get; set; }
        protected int GenotypeLength { get; set; }

        public ResolverBase(double[,] adjacencyMatrix)
        {
            AdjacencyMatrix = adjacencyMatrix;
            GenotypeLength = adjacencyMatrix.GetLength(0);
        }

        public abstract Solution ResolveProblem();
    }
}
