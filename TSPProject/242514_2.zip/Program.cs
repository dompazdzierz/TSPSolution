﻿

using System;
using System.Collections.Generic;
using TSPProject.Resolvers;

namespace TSPProject
{
    class Program
    {
        static void Main(string[] args)
        {
            ResolveProblems(PrepareProblems());

        }

        static void ResolveProblems(List<Problem> problems)
        {
            foreach(Problem problem in problems)
            {
                List<ResolverBase> resolvers = PrepareResolversForProblem(problem.AdjacencyMatrix);
                var solutions = new List<Solution>();
                
                foreach(ResolverBase resolver in resolvers)
                {
                    solutions.Add(resolver.ResolveProblem());
                }

                Console.WriteLine("File: " + problem.FileName);
                Console.WriteLine();
                WriteSolutions(solutions);
            }
        }

        static List<Problem> PrepareProblems()
        {
            var problems = new List<Problem>();
            problems.Add(new Problem("berlin11_modified.tsp"));
            problems.Add(new Problem("berlin52.tsp"));
            problems.Add(new Problem("kroA200.tsp"));

            return problems;
        }

        static List<ResolverBase> PrepareResolversForProblem(double[,] adjacencyMatrix)
        {
            var resolvers = new List<ResolverBase>();
            resolvers.Add(new GreedyAlgorithm(adjacencyMatrix));
            resolvers.Add(new RandomResolver(adjacencyMatrix, 1000));
            resolvers.Add(new GeneticAlgorithm(adjacencyMatrix, 100, 0.7, 0.1, 100, 5));

            return resolvers;
        }

        static void WriteSolutions(List<Solution> solutions)
        {
            foreach(Solution solution in solutions)
            {
                Console.WriteLine("Algorithm: " + solution.ResolverName);
                Console.WriteLine("Best individual: " + solution.Individual);
                Console.WriteLine("Shortest distnace: " + solution.Distance);
                Console.WriteLine();
            }
        }
    }
}
